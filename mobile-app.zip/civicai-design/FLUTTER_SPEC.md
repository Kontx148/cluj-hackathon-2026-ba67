# CivicAI — Flutter Implementation Spec

> Konkrét Flutter widget-fa, theme, és csomag-javaslatok. Cursornak ezt add be a `DESIGN.md`
> mellé ha Flutter target.

## 1. Csomagok (`pubspec.yaml`)
```yaml
dependencies:
  flutter:
    sdk: flutter
  go_router: ^14.0.0          # routing
  google_fonts: ^6.2.1        # Space Grotesk + Inter
  http: ^1.2.0                # RSS + AI hívások
  xml: ^6.5.0                 # RSS parse
  flutter_riverpod: ^2.5.0    # state mgmt (vagy provider/bloc)
  cached_network_image: ^3.3.0
  url_launcher: ^6.2.5        # cikk megnyitás
  shadcn_ui: ^0.17.0          # shadcn-style komponensek Flutterhez
  intl: ^0.19.0
```

## 2. Theme

```dart
final lightTheme = ThemeData(
  useMaterial3: true,
  scaffoldBackgroundColor: const Color(0xFFF7F8FA),
  colorScheme: const ColorScheme.light(
    primary: Color(0xFF3B3F8C),
    onPrimary: Colors.white,
    surface: Colors.white,
    onSurface: Color(0xFF0F1729),
    outline: Color(0xFFE1E6EE),
  ),
  textTheme: TextTheme(
    displayLarge: GoogleFonts.spaceGrotesk(fontSize: 36, fontWeight: FontWeight.w700, letterSpacing: -0.7),
    titleMedium: GoogleFonts.spaceGrotesk(fontSize: 16, fontWeight: FontWeight.w600),
    bodyMedium: GoogleFonts.inter(fontSize: 14, color: const Color(0xFF5A6B85)),
    labelSmall: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1.5),
  ),
);
```

(Dark theme: lásd `DESIGN.md` token táblázat.)

## 3. Route-ok (`go_router`)
- `/` → `FeedScreen` (jelenleg ennyi az MVP)
- később: `/article/:id`, `/vote`, `/laws`

## 4. Widget-fa

```
MaterialApp.router
└─ FeedScreen (Scaffold)
   ├─ AppBar / SliverAppBar
   │   └─ FeedHeader
   │      ├─ Eyebrow ("LOVABLE AI…")
   │      ├─ Title "CivicAI"
   │      ├─ Tagline
   │      └─ Row(LanguageTabs, RefreshButton)
   └─ CustomScrollView
      ├─ SliverToBoxAdapter → FilterSection
      │   ├─ SearchField
      │   ├─ LevelChips (4 pill)
      │   ├─ TopicChips (10 wrap)
      │   ├─ TypeChips (6 wrap)
      │   └─ SourceBadges
      └─ SliverGrid (responsive)
         └─ NewsCard
            ├─ Row(LevelBadge, SourceText)
            ├─ TitleText (maxLines 3, ellipsis)
            ├─ SummaryText (maxLines 4)
            ├─ Wrap(TagChips)
            └─ Row(ImportanceDots, ActionBadge?, OpenLink)
```

## 5. Responsive grid

```dart
LayoutBuilder(builder: (ctx, c) {
  final cross = c.maxWidth >= 1024 ? 3 : c.maxWidth >= 768 ? 2 : 1;
  return SliverGrid.count(crossAxisCount: cross, ...);
});
```

## 6. Állapotkezelés (Riverpod)

```dart
final feedProvider = FutureProvider<List<FeedItem>>((ref) async {
  return FeedService.fetchAndSummarize();
});

final langProvider = StateProvider<Lang>((_) => Lang.hu);
final levelProvider = StateProvider<LevelFilter>((_) => LevelFilter.all);
final topicProvider = StateProvider<String?>((_) => null);
final typeProvider = StateProvider<String?>((_) => null);
final searchProvider = StateProvider<String>((_) => '');

final filteredFeedProvider = Provider<List<FeedItem>>((ref) {
  final items = ref.watch(feedProvider).valueOrNull ?? [];
  // … apply filters
});
```

## 7. AI hívás

Két opció:
- **Lovable AI Gateway proxy** (HTTP POST a `/api/ai` endpointra — backend kell)
- **Direkt Gemini API** Flutterből (kulcs a kliensen — csak demo!)

Ajánlott: kis Cloudflare Worker / Supabase Edge Function, ami a Gemini-t hívja, és Flutter csak a `summary + tags + importance` JSON-t kapja.

## 8. RSS parse

```dart
import 'package:xml/xml.dart';
final doc = XmlDocument.parse(rssBody);
final items = doc.findAllElements('item').map((e) => RssItem(
  title: e.getElement('title')!.innerText,
  link: e.getElement('link')!.innerText,
  description: e.getElement('description')?.innerText ?? '',
  pubDate: e.getElement('pubDate')?.innerText,
));
```

## 9. Komponens-mapping (React → Flutter)

| React (shadcn) | Flutter |
|---|---|
| `<Card>` | `Card` v. `Container` + `BoxDecoration` |
| `<Badge>` | `Container` + `Text` (pill) v. `shadcn_ui` `Badge` |
| `<Button>` | `ElevatedButton` / `OutlinedButton` |
| `<Tabs>` | `SegmentedButton<Lang>` |
| `<Input>` | `TextField` |
| `<Skeleton>` | `shimmer` package |
| `line-clamp-3` | `Text(maxLines: 3, overflow: TextOverflow.ellipsis)` |
| `backdrop-blur` | `BackdropFilter(filter: ImageFilter.blur(...))` |

## 10. Min. fájl-struktúra

```
lib/
├── main.dart
├── theme.dart
├── models/
│   └── feed_item.dart
├── services/
│   ├── feed_service.dart        # RSS + AI
│   └── ai_service.dart
├── state/
│   └── providers.dart
├── screens/
│   └── feed_screen.dart
└── widgets/
    ├── feed_header.dart
    ├── filter_section.dart
    ├── news_card.dart
    ├── level_badge.dart
    └── importance_dots.dart
```
