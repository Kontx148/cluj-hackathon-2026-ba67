# CivicAI — Design Specification

> Stack-agnostic design dokumentum. Forrásként szolgál Cursornak / bármilyen AI-kódolónak,
> hogy újraépítse az appot tetszőleges keretrendszerben (Flutter, React Native, SwiftUI, stb.).

---

## 1. Termék — mit csinál?

**CivicAI** = AI-által summázott politikai/civic news feed három szinten (EU / Románia / Helyi),
három nyelven (HU / RO / EN), tagekkel és szűrőkkel. A felhasználó látja:
- Mi történt (cím + forrás)
- Mit jelent (AI összefoglaló a választott nyelven)
- Mennyire fontos (1–5 pont)
- Lehet-e civil cselekvés (zöld badge)
- Milyen témakör / típus (tag chip-ek)

Hosszabb távú vízió: digitális ID-alapú anonim szavazás + törvény-magyarázó chat.
**Ez a spec csak az MVP olvasó/feed részét írja le.**

---

## 2. Design tokens

### Színek (oklch → hex közelítés Flutter/natív környezethez)

| Token | Light hex | Dark hex | Használat |
|---|---|---|---|
| `background` | `#F7F8FA` | `#0E1422` | App háttér |
| `foreground` | `#0F1729` | `#F5F7FB` | Fő szöveg |
| `card` | `#FFFFFF` | `#1A2238` | Kártya háttér |
| `primary` | `#3B3F8C` | `#E8EBF6` | CTA, aktív chip, link |
| `primary-foreground` | `#FFFFFF` | `#1A2238` | Primary-en lévő szöveg |
| `muted` | `#EEF1F6` | `#222B44` | Tag chip háttér |
| `muted-foreground` | `#5A6B85` | `#9AA6BE` | Másodlagos szöveg |
| `border` | `#E1E6EE` | `#FFFFFF1A` | Vékony határvonalak |
| `accent-success` | `#059669` | `#10B981` | "Civil akció lehetséges" badge |
| `accent-importance` | `#3B3F8C` | `#E8EBF6` | Fontosság pontok (●) |

Border radius: `12px` alap, `9999px` (pill) a chipekhez.

### Tipográfia

- **Fejlécek** (h1–h4): `Space Grotesk` 600–700, letter-spacing `-0.02em`
- **Body**: `Inter` 400/500
- **Mono** (fontosság pöttyök): rendszer monospace

Méretek (mobil):
- App cím (h1): 32–36px / 700
- Kártya cím: 16px / 600, max 3 sor (`line-clamp`)
- Body / összefoglaló: 14px / 400, max 4 sor
- Tag / chip: 11–12px
- Eyebrow (pl. "Lovable AI által generált…"): 11px uppercase, tracking `0.15em`, muted

### Spacing skála
`4 / 8 / 12 / 16 / 24 / 32 / 48` — Tailwind alap.

### Árnyék
Kártya hover: `0 10px 30px -10px rgba(15,23,41,0.15)`.

---

## 3. Layout

### Mobil (< 768px) — alapértelmezett
- Egy oszlop, 16px padding
- Header sticky, blur háttér
- Szűrő chip-ek vízszintesen scrollolhatnak (vagy törnek)
- Kártyák 1 oszlopban

### Tablet (768–1024px)
- Kártyák 2 oszlopban (`gap: 16px`)
- Max szélesség: 768px középre

### Desktop (> 1024px)
- Kártyák 3 oszlopban
- Konténer max-width: 1152px (`max-w-6xl`), középre, 16px oldalsó padding

---

## 4. Képernyők

### 4.1 Header
```
┌─────────────────────────────────────────┐
│ ✨ LOVABLE AI ÁLTAL GENERÁLT (GEMINI)   │  ← eyebrow, muted, uppercase
│                                         │
│ CivicAI                                 │  ← h1, 36px/700
│ EU, román és kolozsvári politikai…      │  ← tagline, muted
│                                         │
│ [HU][RO][EN]      [↻ Frissítés]         │  ← nyelv tabs + refresh btn
└─────────────────────────────────────────┘
```
- Alja: 1px `border` szín alsó vonal
- Háttér: `card/50` + backdrop blur

### 4.2 Szűrő szekció
Sorrend felülről:
1. **Search input** (max-width 400px) — placeholder lokalizált
2. **SZINT:** label + 4 pill gomb (`Mind`, `EU`, `Romania`, `Local`) — aktív = `primary`
3. **TÉMAKÖRÖK:** label + 10 tag chip (toggle, multi-NO, single)
   - `#egeszsegugy #oktatas #adozas #infrastruktura #kornyezet #biztonsag #digitalizacio #szocialis #energia #honvedelem`
4. **TÍPUS:** label + 6 tag chip
   - `#torveny-hatalyos #torvenyjavaslat #szavazas-kozeleg #partprogram #kepviselo-allaspont #helyi-dontes`
5. **Forrás:** label + secondary badge-ek (read-only, mutatja az aggregált forrásokat)

Chip stílus:
- Inaktív: `border border-border bg-card text-foreground` + hover → `border-primary/60`
- Aktív: `border-primary bg-primary text-primary-foreground`
- Padding: `px-12 py-4`, full-rounded, 11px font

### 4.3 News Card
```
┌─────────────────────────────────────────┐
│ [🏛 Romania]              G4Media       │  ← level badge bal + source jobb
│                                         │
│ Cím három sorban max, line-clamp-3     │  ← 16px/600
│                                         │
│ AI összefoglaló a kiválasztott nyelven, │  ← 14px muted, line-clamp-4
│ kb. 4 sorban…                           │
│                                         │
│ [#egeszsegugy] [#torvenyjavaslat] …     │  ← max 6 chip, 10px
│                                         │
│ ●●●○○  [Civil akció]      Megnyitás ↗   │  ← footer
└─────────────────────────────────────────┘
```
- Bg: `card`, border `border`, radius 12px
- Padding: 16px
- Footer: `flex justify-between`, 12px
- Level badge ikon: EU = globe, Romania = landmark, Local = building
- Importance: 5 pötty, kitöltött = `foreground`, üres = 30% opacity
- "Civil akció" badge: csak ha `actionPossible === true`, zöld háttér
- "Megnyitás ↗" → új tab az eredeti cikkre

### 4.4 Üres állapot
Középre: `"Nincs találat a jelenlegi szűrőkre."` muted, 60px függőleges padding.

### 4.5 Footer
`CivicAI · Hackathon MVP · Cluj 2026` — kicsi, muted, középre.

---

## 5. Állapotok és viselkedés

- **Loading**: Skeleton kártyák (6 db, 224px magas, `card` bg pulse)
- **Frissítés gomb**: pörgő ikon `isFetching` alatt
- **Nyelv váltás**: nem fetchel újra, csak a megjelenített `summary_xx` és `t.*` szövegek váltanak
- **Search**: kliens oldali fuzzy match a `title + source + tags` mezőkön
- **Szűrők kombinálva**: AND logika (level ÉS topic ÉS type ÉS search)
- **Cache**: feed adat 5 perc stale, server oldali AI 30 perc in-memory

---

## 6. Adatmodell — `FeedItem`
```ts
type Level = "EU" | "Romania" | "Local";
interface FeedItem {
  id: string;
  title: string;
  link: string;
  description: string;
  source: string;          // pl. "G4Media"
  level: Level;
  publishedAt: string;     // ISO
  summary_hu?: string;
  summary_ro?: string;
  summary_en?: string;
  tags?: string[];         // pl. ["#oktatas", "#torvenyjavaslat"]
  importance?: number;     // 1..5
  actionPossible?: boolean;
}
```

Források (RSS):
- EU: `https://epthinktank.eu/feed/`
- RO: g4media.ro, digi24.ro, hotnews.ro, pressone.ro
- Local (HU): maszol.ro, transtelex.ro

AI feldolgozás:
- Modell: Gemini 3 Flash (Lovable AI Gateway) — bárki tud Claude / OpenAI-t cserélni
- Prompt: cím + leírás → HU/RO/EN összefoglaló (max 2 mondat), tag-ek, importance 1–5, actionPossible bool

---

## 7. I18n — string tábla

Lásd `STRINGS.json` a csomagban. 3 nyelv × kb. 14 kulcs.

---

## 8. Inspirációs screenshotok
Lásd `/screens/` mappa.
