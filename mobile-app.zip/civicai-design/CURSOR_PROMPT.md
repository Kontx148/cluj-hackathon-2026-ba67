# Cursor Prompt — másold be Cursor chatbe

Építsd újra a CivicAI nevű alkalmazást **Flutter** (vagy [add meg a stack-et]) keretrendszerben az alábbi specifikációk alapján.

**Kötelezően olvasd be ezeket a fájlokat ebben a sorrendben:**
1. `DESIGN.md` — termékleírás, design tokenek, layout, képernyők, viselkedés
2. `FLUTTER_SPEC.md` — konkrét widget-fa, theme, csomagok, fájl-struktúra (ha Flutter)
3. `STRINGS.json` — összes UI szöveg HU/RO/EN-en
4. `screens/*.png` — vizuális referencia screenshotok

**Követelmények:**
- Pixel-pontos egyezés a screenshotokkal, mobil first
- Reszponzív: 1 / 2 / 3 oszlopos kártya grid (mobil / tablet / desktop)
- 3 nyelvű felület, futásidőben váltható
- AI-summary integráció: most mock adatból, később valódi Gemini hívás
- Tiszta architektúra: models / services / state / screens / widgets

**Adatforrás MVP-hez:**
A `services/feed_service.dart`-ban először használj mock JSON listát (10 elem), és csak utána kösd rá a valódi RSS + Gemini pipeline-ra.

**Ne csinálj most:**
- szavazási rendszert (külön scope)
- adatbázist
- bejelentkezést

Kezdj a `main.dart` + `theme.dart` + `FeedScreen` skeleton-jával, aztán haladj komponensenként. Minden lépés után írd ki, mi készült el.
